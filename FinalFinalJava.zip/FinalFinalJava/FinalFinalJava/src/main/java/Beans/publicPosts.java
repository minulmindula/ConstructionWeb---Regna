package Beans;

import java.io.InputStream;
import java.sql.Timestamp;

public class publicPosts {

    private String postTitle;
    private String postedBy;
    private String Pdes;
    private Timestamp date;
    private InputStream image;

    public void publicPosts(String postTitle, String postedBy, String Pdes, Timestamp date, InputStream image){
        this.date=date;
        this.image=image;
        this.Pdes=Pdes;
        this.postedBy=postedBy;
        this.postTitle=postTitle;
    }

    public void publicPosts(){

    }

    public String getPostTitle(){return postTitle;}
    public void setPostTitle(String postTitle){this.postTitle=postTitle;}

    public String getPostedBy(){return postedBy;}
    public void setPostedBy(String postedBy){this.postedBy=postedBy;}

    public String getPdes(){return Pdes;}
    public void setPdes(String Pdes){this.Pdes=Pdes;}

    public Timestamp getDate(){return date;}
    public void setDate(Timestamp date){this.date=date;}

    public InputStream getImage(){return image;}
    public void setImage(InputStream image){this.image=image;}


}
