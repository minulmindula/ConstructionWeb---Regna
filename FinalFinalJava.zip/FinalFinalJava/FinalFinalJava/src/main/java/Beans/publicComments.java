package Beans;

public class publicComments {

    private String commentedBy;
    private String comment;
    private String date;
    private String postID;

    public void publicComments(String commentedBy, String comment, String date, String postID){
        this.comment=comment;
        this.commentedBy=commentedBy;
        this.date=date;
        this.postID=postID;
    }

    public String getCommentedBy() {return commentedBy;}
    public void setCommentedBy(String commentedBy){this.commentedBy=commentedBy;}

    public String getComment() {return comment;}
    public void setComment(String comment){this.comment=comment;}

    public String getDate() {return date;}
    public void setDate(String date){this.date=date;}

    public String getPostID() {return postID;}
    public void setPostID(String postID){this.postID=postID;}

}
