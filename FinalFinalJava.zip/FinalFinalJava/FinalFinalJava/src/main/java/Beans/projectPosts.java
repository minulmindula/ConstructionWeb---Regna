package Beans;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Timestamp;

public class projectPosts {

    private String postText;
    private String postedBy;
    private Timestamp date;
    private String postDes;
    private String projID;
    private InputStream image;

    public void projectPosts(String postText, String postedBy, Timestamp date, String postDes, String projID, InputStream image){
        this.postText=postText;
        this.postedBy=postedBy;
        this.date=date;
        this.postDes=postDes;
        this.projID=projID;
        this.image=image;
    }

    public void projectPosts(){

    }

    public String getPostText(){
        return postText;
    }
    public void setPostText(String postText){
        this.postText=postText;
    }

    public String getPostedBy(){
        return postedBy;
    }
    public void setPostedBy(String postedBy){
        this.postedBy=postedBy;
    }

    public Timestamp getDate(){
        return date;
    }
    public void setDate(Timestamp date){
        this.date=date;
    }

    public String getPostDes(){
        return postDes;
    }
    public void setPostDes(String postDes){
        this.postDes=postDes;
    }

    public InputStream getImage(){
        return image;
    }
    public void setImage(InputStream image){
        this.image=image;
    }

    public String getProjID(){
        return projID;
    }
    public void setProjID(String projID){
        this.projID=projID;
    }
}
