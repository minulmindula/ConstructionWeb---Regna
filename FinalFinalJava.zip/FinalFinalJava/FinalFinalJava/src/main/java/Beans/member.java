package Beans;


public class member {

    private String name;
    private String projID;
    private String date;
    private String email;

    public member(String name, String projID, String date, String email){
        this.name=name;
        this.projID=projID;
        this.date=date;
        this.email=email;
    }

    public member(){

    }

    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }

    public String getProjID(){
        return projID;
    }
    public void setProjID(String projID){
        this.projID=projID;
    }

    public String getDate(){
        return date;
    }
    public void setDate(String date){
        this.date=date;
    }

    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email=email;
    }

}
