package Beans;

public class comments {

    private String postID;
    private String comment;
    private String commentedBy;
    private String date;

    public comments(String postID, String comment, String commentedBy, String date){
        this.postID=postID;
        this.comment=comment;
        this.commentedBy=commentedBy;
        this.date=date;
    }

    public comments(){

    }

    public String getPostID(){
        return postID;
    }
    public void setPostID(String postID){
        this.postID=postID;
    }

    public String getComment(){return comment;}
    public void setComment(String comment){this.comment=comment;}

    public String getCommentedBy(){return commentedBy;}
    public void setCommentedBy(String commentedBy){this.commentedBy=commentedBy;}


}
