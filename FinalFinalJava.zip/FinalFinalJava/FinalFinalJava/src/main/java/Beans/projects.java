package Beans;

import java.sql.Timestamp;

public class projects {

    private String pID;
    private String projectName;
    private String owner;
    private Timestamp startDate;
    private String description;



    public projects(String pID, String projectName, String description, Timestamp startDate, String owner) {
        this.pID=pID;
        this.projectName=projectName;
        this.owner=owner;
        this.startDate=startDate;
        this.description=description;
    }

    public projects(){

    }

    public void existingProject(){

    }
    public String getpID(){
        return pID;
    }
    public void setpID(String pID){
        this.pID=pID;
    }

    public String getProjectName(){
        return projectName;
    }
    public void setProjectName(String projectName){
        this.projectName=projectName;
    }

    public String getOwner(){
        return owner;
    }
    public void setOwner(String owner){
        this.owner=owner;
    }

    public String getDescription(){
        return description;
    }
    public void setDescription(String description){
        this.description=description;
    }

    public Timestamp getStartDate(){
        return startDate;
    }
    public void setStartDate(Timestamp startDate){
        this.startDate=startDate;
    }

}
