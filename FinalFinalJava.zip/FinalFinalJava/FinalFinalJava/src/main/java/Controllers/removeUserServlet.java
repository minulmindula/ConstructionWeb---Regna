package Controllers;

import Beans.DBconnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class removeUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        String t = (String)session.getAttribute("mName");
        String qw = request.getParameter("uName");

        String sql = "DELETE FROM `membergroup` WHERE memberName = '"+qw+"'";

        try{
            Connection connect = DBconnection.dbConnection();
            PreparedStatement stmt = connect.prepareStatement(sql);

            int row = stmt.executeUpdate();

            if(row > 0){
                response.sendRedirect("member.jsp");
            }


        }catch(SQLException e){
            e.printStackTrace();
        }


    }

}
