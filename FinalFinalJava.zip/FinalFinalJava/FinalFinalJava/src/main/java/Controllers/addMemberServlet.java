package Controllers;

import Beans.DBconnection;
import Beans.member;
import Model.Application;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class addMemberServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        HttpSession session = request.getSession();

        String memberUName = request.getParameter("userMemberName");
        String date = new Timestamp(System.currentTimeMillis()).toString();
        String email = request.getParameter("userMemberEmail");
        String projID = (String)session.getAttribute("pID");

        member mem = new member();
        mem.setName(memberUName);
        mem.setDate(date);
        mem.setEmail(email);
        mem.setProjID(projID);

        Application app = new Application();
        int row = app.addMember(mem);

        if(row > 0){
            response.sendRedirect("member.jsp");
        }


    }
}
