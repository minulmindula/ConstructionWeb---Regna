package Controllers;

import Beans.DBconnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.transform.Result;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class postsPermissionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();

        String qw = request.getParameter("uName");
        String c = request.getParameter("permission");
        String ww =(String)session.getAttribute("pID");

        String sql = "UPDATE `membergroup` SET `P`='"+c+"' WHERE memberName ='"+qw+"' AND projID = '"+ww+"' ";


        try {
            Connection connect = DBconnection.dbConnection();
            PreparedStatement stmt = connect.prepareStatement(sql);
            int rows = stmt.executeUpdate();
            String lol;

            if(rows > 0){
                response.sendRedirect("member.jsp");
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
        }


    }
}
