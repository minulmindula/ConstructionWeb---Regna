package Controllers;

import Beans.user;
import Model.Application;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Parameter;
import java.util.Base64;

@MultipartConfig(maxFileSize = 999999999)
public class editProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();

        String fn;
        String ln;
        String address;
        String num;
        String email;
        String bio;
        String image = null;
        Part filepart = null;

        byte[] imgIS = null;

        if(request.getParameter("fn") == null){
            fn = (String)session.getAttribute("fn");
        }else{
            fn = request.getParameter("fn");
        }

        if(request.getParameter("ln") == null){
            ln = (String)session.getAttribute("ln");
        }else{
            ln = request.getParameter("ln");
        }

        if(request.getParameter("address") == null){
            address = (String)session.getAttribute("address");
        }else{
            address = request.getParameter("address");
        }

        if(request.getParameter("phone") == null){
            num = (String)session.getAttribute("phonenumber");
        }else{
            num = request.getParameter("phone");
        }

        if( request.getParameter("email") == null){
            email = (String)session.getAttribute("email");
        }else{
            email = request.getParameter("email");
        }

        if(request.getParameter("bio") == null){
            bio = (String)session.getAttribute("bio");
        }else{
            bio = request.getParameter("bio");
        }

        String un = (String)session.getAttribute("username");

        InputStream inputStream = null;

        if(request.getPart("pImage") == null){
            System.out.println("don't insert!");
        }else{
            filepart = request.getPart("pImage");
        }


        if(filepart != null){

            inputStream = filepart.getInputStream();
        }

        user u = new user();

        u.setFirstName(fn);
        u.setLastName(ln);
        u.setAddress(address);
        u.setEmail(email);
        u.setPhonenumber(num);
        u.setImage(inputStream);
        u.setBio(bio);
        u.setUsername(un);

        Application app = new Application();
        int row = app.editProfile(u);

        if(row > 0){
            response.sendRedirect("editProfileSuccess.jsp");
        }


    }
}
