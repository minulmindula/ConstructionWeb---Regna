package Controllers;

import Beans.projects;
import Model.Application;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;

public class createProjectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{


        HttpSession session = request.getSession();

        String projectName = request.getParameter("projectname");
        String description = request.getParameter("description");
        Timestamp date = new Timestamp(System.currentTimeMillis());
        String uname = (String)session.getAttribute("username");

        projects enterproject = new projects();

        enterproject.setProjectName(projectName);
        enterproject.setOwner(uname);
        enterproject.setDescription(description);
        enterproject.setStartDate(date);


            Application application = new Application();
            int row = application.createProject(enterproject);

            if(row > 0){

                session.setAttribute("projtitle", projectName);

                response.sendRedirect("existingProjects.jsp");
            }else{
                System.out.println("Project errror!");
            }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

    }
}
