package Controllers;

import Beans.DBconnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

public class deleteProject extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String projID = request.getParameter("projectID");
        String sql = "DELETE FROM projects WHERE projectID = ? ";

        System.out.println(projID);

        try{
            Connection connect = DBconnection.dbConnection();
            PreparedStatement pstmt = connect.prepareStatement(sql);
            pstmt.setString(1, projID);
            int row = pstmt.executeUpdate();

            if(row > 0){
                response.sendRedirect("existingProjects.jsp");
            }


        }catch(SQLException e){
            e.printStackTrace();
        }


    }
}
