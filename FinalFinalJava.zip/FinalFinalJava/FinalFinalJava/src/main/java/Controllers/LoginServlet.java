package Controllers;

import Beans.loginUser;
import Model.Application;
import org.mindrot.jbcrypt.BCrypt;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

public class LoginServlet extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String x = null;
        String y = null;
        String fn = null;
        String ln = null;
        String email = null;
        String occupation = null;
        String phone = null;
        String add = null;
        String image = null;
        String bio = null;
        byte[] imagetest = null;

        String pw = request.getParameter("password");
        String uname = request.getParameter("username");


        HttpSession session = null;

        loginUser log = new loginUser();

        log.setPassword(pw);
        log.setUsername(uname);


        try{
            Application application = new Application();
            ResultSet rs = null;
            rs = application.loginUser(log);



            while(rs.next()){
                x = rs.getString("username");
                y = rs.getString("password");

                fn = rs.getString("firstName");
                ln = rs.getString("lastName");
                email = rs.getString("email");
                occupation = rs.getString("occupation");
                phone = rs.getString("phone");
                add = rs.getString("address");
                bio = rs.getString("bio");

                imagetest = rs.getBytes("image");

                if(imagetest == null){
                    System.out.println("lol");
                }else{
                    image = Base64.getEncoder().encodeToString(imagetest);
                }


                if(BCrypt.checkpw(pw, y)){

                    session = request.getSession();
                    session.setAttribute("username", uname);
                    session.setAttribute("fn", fn);
                    session.setAttribute("ln", ln);
                    session.setAttribute("email", email);
                    session.setAttribute("occupation", occupation);
                    session.setAttribute("phonenumber", phone);
                    session.setAttribute("address", add);
                    session.setAttribute("bio", bio);

                    session.setAttribute("profileImage", image);


                    request.getRequestDispatcher("home.jsp").forward(request,response);
                }
                else{
                    response.sendRedirect("signInError.jsp");
                }
            }



        }catch(SQLException e){
            e.printStackTrace();
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {




    }
}
