package Controllers;

import Beans.DBconnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class addCommentPrivate extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();


        String postIDm = request.getParameter("postIDq");
        String commenttxt = request.getParameter("comment");
        String unameS = (String)session.getAttribute("username");
        String date = new Timestamp(System.currentTimeMillis()).toString();



        String sql = "INSERT INTO `privateComment`(`postID`, `commentedBy`, `comment`, `date`) VALUES (?,?,?,?)";

        try{
            Connection connect = DBconnection.dbConnection();
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, postIDm);
            stmt.setString(2, unameS);
            stmt.setString(3, commenttxt);
            stmt.setString(4, date);

            int rows = stmt.executeUpdate();

            if(rows > 0){
                response.sendRedirect("viewProject.jsp");
            }

        }catch(SQLException e){
            e.printStackTrace();
        }


    }
}
