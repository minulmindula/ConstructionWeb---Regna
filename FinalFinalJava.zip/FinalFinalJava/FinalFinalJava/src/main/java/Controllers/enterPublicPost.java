package Controllers;

import Beans.DBconnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

@MultipartConfig (maxFileSize = 999999999)
public class enterPublicPost extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();

        String postDescription = request.getParameter("posttxt");

        String postTitle = request.getParameter("postTitle");

        Timestamp date = new Timestamp(System.currentTimeMillis());

        String postedBy = session.getAttribute("username").toString();


        InputStream inputStream = null;

        Part filepart = request.getPart("image");

        if(filepart != null){

            inputStream = filepart.getInputStream();
        }

        try{
                Connection connect = DBconnection.dbConnection();

                String sql = "INSERT INTO postsPublic(`postTitle`, `postedBy`, `Pdescription`, `date`, `image`)VALUES(?,?,?,?,?)";

                PreparedStatement stmt = connect.prepareStatement(sql);

                                  stmt.setString(1, postTitle);
                                  stmt.setString(2, postedBy);
                                  stmt.setString(3, postDescription);
                                  stmt.setTimestamp(4, date);
                                  stmt.setBlob(5, inputStream);

                int rows = stmt.executeUpdate();

                if(rows > 0){
                    response.sendRedirect("newsfeed.jsp");
            }


        }catch(SQLException se){
            se.printStackTrace();
        }

    }
}
