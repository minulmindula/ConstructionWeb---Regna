package Controllers;

import Beans.DBconnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class existingProjectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        String id = request.getParameter("pID");
        HttpSession session = request.getSession();
        String pID = null;
        String oName = null;
        String pName = null;
        String des = null;

        try{
            Connection connect = DBconnection.dbConnection();
            String sql = "SELECT * FROM projects WHERE projectID='"+id+"'";
            PreparedStatement stmt = connect.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            if(rs.next()){
                pName = rs.getString("projectName");
                pID = rs.getString("projectID");
                oName = rs.getString("projectOwnerName");
                des = rs.getString("description");

                session.setAttribute("pID", pID);
                session.setAttribute("oName", oName);
                session.setAttribute("pName", pName);
                session.setAttribute("des", des);

                response.sendRedirect("viewProject.jsp");
            }



        }catch(SQLException e){
            e.printStackTrace();
        }





    }
}
