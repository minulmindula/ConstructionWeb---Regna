package Controllers;

import Beans.projectPosts;
import Model.Application;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Timestamp;

@MultipartConfig(maxFileSize = 999999999)
public class enterPostsProject extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        HttpSession session = request.getSession();

        String postText = request.getParameter("title");
        String des = request.getParameter("posttxt");
        Timestamp date = new Timestamp(System.currentTimeMillis());
        String uname = (String)session.getAttribute("username");
        String projID = (String)session.getAttribute("pID");

        InputStream inputStream = null;

        Part filepart = request.getPart("image");

        if(filepart != null){

            inputStream = filepart.getInputStream();
        }

        projectPosts posts = new projectPosts();

        posts.setPostDes(des);
        posts.setPostText(postText);
        posts.setDate(date);
        posts.setPostedBy(uname);
        posts.setProjID(projID);
        posts.setImage(inputStream);


        Application application = new Application();
        int row = application.enterPost(posts);

        if(row > 0){

            session.setAttribute("postTitle", postText);
            session.setAttribute("postedByUser", uname);
            session.setAttribute("postDescription", des);
            session.setAttribute("postedDate", date);
            session.setAttribute("image", inputStream);

            response.sendRedirect("viewProject.jsp");
        }else{
            System.out.println("error!");
        }

    }
}
