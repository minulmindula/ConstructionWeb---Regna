package Controllers;

import Beans.regUser;
import Model.Application;
import org.mindrot.jbcrypt.BCrypt;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        HttpSession session = request.getSession();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String fname = request.getParameter("firstName");
        String lname = request.getParameter("lastName");
        String address = request.getParameter("address");
        String dob = request.getParameter("dob");
        String occ = request.getParameter("occupation");
        String sex = request.getParameter("gender");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");

        int workload = 12;
        String salt = BCrypt.gensalt(workload);
        String hashedPassword = BCrypt.hashpw(password,salt);
        regUser reguser = new regUser();

        reguser.setUsername(username);
        reguser.setPassword(hashedPassword);
        reguser.setAddress(address);
        reguser.setFirstName(fname);
        reguser.setLastName(lname);
        reguser.setOccupation(occ);
        reguser.setDob(dob);
        reguser.setEmail(email);
        reguser.setSex(sex);
        reguser.setPhonenumber(phone);

        Application application = new Application();
        int row = application.regUser(reguser);

        if(row > 0){
            response.sendRedirect("signUpConfirmation.jsp");
        }else{
            response.sendRedirect("signUpError.jsp");
        }
    }
}
