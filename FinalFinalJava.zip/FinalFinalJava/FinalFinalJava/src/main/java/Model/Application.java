package Model;

import Beans.*;

import javax.servlet.http.HttpSession;
import java.io.InputStream;
import java.sql.*;

public class Application {

    Connection connect = DBconnection.dbConnection();

    public ResultSet loginUser(loginUser loguser) {


        ResultSet resultSet = null;

        String uname = loguser.getUsername();
        String pw = loguser.getPassword();


        try {

            String sql = "SELECT * FROM users WHERE username='" + uname + "'";
            PreparedStatement stmt = connect.prepareStatement(sql);
            resultSet = stmt.executeQuery();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return resultSet;
    }


    public int regUser(regUser user) {

        String uname = user.getUsername();
        String pw = user.getPassword();
        String fname = user.getFirstName();
        String lname = user.getLastName();
        String address = user.getAddress();
        String dob = user.getDob();
        String occ = user.getOccupation();
        String sex = user.getSex();
        String email = user.getEmail();
        String phonenumber = user.getPhonenumber();

        int rows = 0;

        try {
            String sql = "INSERT INTO `users`(`firstName`, `lastName`, `username`, `email`, `password`, `phone`, `gender`, `address`, `occupation`) VALUES (?,?,?,?,?,?,?,?,?)";

            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, fname);
            stmt.setString(2, lname);
            stmt.setString(3, uname);
            stmt.setString(4, email);
            stmt.setString(5, pw);
            stmt.setString(6, phonenumber);
            stmt.setString(7, sex);
            stmt.setString(8, address);
            stmt.setString(9, occ);

            rows = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;

    }

    public ResultSet myExistingProject(String username, String projID) {

        ResultSet rss = null;
        int count = 0;


        try {

            String sqlo = "SELECT * FROM projects WHERE projectOwnerName=? OR projectID =? ORDER BY startdate DESC";
            PreparedStatement stmt = connect.prepareStatement(sqlo);
            stmt.setString(1, username);
            stmt.setString(2, projID);

            rss = stmt.executeQuery();


        } catch (SQLException w) {
            w.printStackTrace();
        }

        return rss;

    }


    public ResultSet myProjects(String username) {

        ResultSet rs = null;

        try {


            String sql = "SELECT * FROM membergroup WHERE memberName=?";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, username);
            rs = stmt.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rs;

    }


    public int createProject(projects cp) {

        String ptitle = cp.getProjectName();
        String description = cp.getDescription();
        Timestamp date = cp.getStartDate();
        String owner = cp.getOwner();

        int rows = 0;

        try {
            String sql = "insert into `projects`(`projectname`, `projectownername`, `description`, `startdate`) values (?,?,?,?)";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, ptitle);
            stmt.setString(2, owner);
            stmt.setString(3, description);
            stmt.setTimestamp(4, date);
            rows = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rows;
    }
//
//    public ResultSet showPostBarOwner(String username) {
//
//        ResultSet rs = null;
//
//        try {
//            String sql = SELECT * FROM projects WHERE projectOwnerName=?";
//            PreparedStatement stmt = connect.prepareStatement(sql);
//            stmt.setString(1, username);
//            rs = stmt.executeQuery();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//
//        }
//
//        return rs;
//    }

    public ResultSet showPostBarMember(String username) {

        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM membergroup WHERE memberName = ? AND P = ?";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setInt(2, 1);
            rs = stmt.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();

        }

        return rs;


    }

    public int enterPost(projectPosts pp) {
        String projID = pp.getProjID();
        String posttxt = pp.getPostText();
        String postDes = pp.getPostDes();
        String postedby = pp.getPostedBy();
        Timestamp date = pp.getDate();
        InputStream images = pp.getImage();

        int rows = 0;

        try {
            String sql = "INSERT INTO posts(`projID`, `postTitle`, `postedBy`, `Pdescription`, `date`, `image`)VALUES(?,?,?,?,?,?)";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(2, posttxt);
            stmt.setString(3, postedby);
            stmt.setString(4, postDes);
            stmt.setTimestamp(5, date);
            stmt.setString(1, projID);
            stmt.setBlob(6, images);


            rows = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }


        return rows;
    }

    public ResultSet showPrivatePosts(projectPosts p) {

        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM posts WHERE projID=? ORDER BY date DESC ";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, p.getProjID());
            rs = stmt.executeQuery();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rs;

    }

    public ResultSet showPrivateComment(comments c) {
        ResultSet rs = null;


        try {
            String sqlcomment = "SELECT * FROM privatecomment WHERE postID = ? ORDER BY date DESC";
            PreparedStatement stmt = connect.prepareStatement(sqlcomment);
            stmt.setString(1, c.getPostID());
            rs = stmt.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rs;

    }

    public ResultSet showAddMembers(String username) {

        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM users WHERE username != ?";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, username);
            rs = stmt.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rs;
    }

    public ResultSet showMembers(String projID) {

        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM membergroup WHERE projID='" + projID + "'";
            PreparedStatement stmt = connect.prepareStatement(sql);
            rs = stmt.executeQuery();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rs;

    }

    public int addMember(member m) {

        String name = m.getName();
        String date = m.getDate();
        String email = m.getEmail();
        String projID = m.getProjID();

        int rows = 0;

        String sql = "INSERT INTO `membergroup`(`projID`,`memberName`, `dateadded`, `email`, `P`) VALUES (?,?,?,?,?)";

        try {

            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, projID);
            stmt.setString(2, name);
            stmt.setString(3, date);
            stmt.setString(4, email);
            stmt.setString(5, "0");

            rows = stmt.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rows;


    }


    public ResultSet checkOwnerP(String username, String pID){

        String sql = "SELECT * FROM projects WHERE projectID = ? AND projectOwnerName = ?";
        ResultSet rs = null;

        try{
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, pID);
            stmt.setString(2, username);
            rs = stmt.executeQuery();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return rs;

    }

    public ResultSet editViewProfile(String username){

        ResultSet rs = null;

        try{
            String sql = "SELECT * FROM users WHERE username = ? ";
            PreparedStatement stmt = connect.prepareStatement(sql);
            stmt.setString(1, username);
            rs = stmt.executeQuery();


        }catch (SQLException e){
            e.printStackTrace();
        }


        return rs;
    }

    public int editProfile(user u){

        int row = 0;

        String fn = u.getFirstName();
        String ln = u.getLastName();
        String address = u.getAddress();
        String email = u.getEmail();
        String num = u.getPhonenumber();
        String bio = u.getBio();
        InputStream image = u.getImage();
        String un = u.getUsername();

        try{

            String sql = "UPDATE `users` SET `firstName`=?,`lastName`=?,`email`=?,`phone`=?,`address`=?,`bio`=?,`image`=? WHERE username = '"+un+"' ";

            PreparedStatement stmt = connect.prepareStatement(sql);

            stmt.setString(1, fn);
            stmt.setString(2, ln);
            stmt.setString(3, email);
            stmt.setString(4, num);
            stmt.setString(5, address);
            stmt.setString(6, bio);
            stmt.setBlob(7, image);

            row = stmt.executeUpdate();


        }catch (SQLException e){
            e.printStackTrace();
        }

return row;

    }

    public ResultSet showPublicPosts(){

            ResultSet rs = null;

            String sql = "SELECT * FROM postsPublic ORDER BY date DESC";

                try{
                        Statement stmt = connect.createStatement();
                        rs = stmt.executeQuery(sql);

                }catch (SQLException se){
                        se.printStackTrace();
                }

            return rs;
    }


    public ResultSet showPublicComments(String pubPostID){

            ResultSet rs = null;

            String sql = "SELECT * FROM publiccomments WHERE postID = ? ";

                try{
                        PreparedStatement pstmt = connect.prepareStatement(sql);
                        pstmt.setString(1, pubPostID);
                        rs = pstmt.executeQuery();

                }catch (SQLException se){
                        se.printStackTrace();
                }

            return rs;

    }


}